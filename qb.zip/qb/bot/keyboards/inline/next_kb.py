from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

step1 = InlineKeyboardMarkup(row_width=1)
n1 = InlineKeyboardButton("Далее", callback_data='step1')
step1.add(n1)

step2 = InlineKeyboardMarkup(row_width=1)
n2 = InlineKeyboardButton("Далее", callback_data='step2')
step2.add(n2)