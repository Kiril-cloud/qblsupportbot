from environs import Env


env = Env()
env.read_env()

BOT_TOKEN = "1760713249:AAFiOBCccR4bGBARP7xoKuGb-ke5Q5jix_o"
ADMINS = ""
# 1603355825:AAEtKLn9zBoKdVvg7d_wXnRc047145E8U3M