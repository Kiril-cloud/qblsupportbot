from aiogram import types
from aiogram.dispatcher.filters.builtin import CommandStart
from aiogram.types.message import ContentType

from loader import dp, bot
from states import step
from keyboards.inline import step1

# Test
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton


YOOTOKEN = "381764678:TEST:27869"

sub = InlineKeyboardMarkup(row_width=1)
s = InlineKeyboardButton('Купить подписку', callback_data='sub')
sub.add(s)

@dp.callback_query_handler(text="sub")
async def submonth(call: types.CallbackQuery):
    await bot.send_invoice(chat_id=call.from_user.id, title="Оформление подписки", 
    description="Доступ к закрытому чату курса по программированию с экспертами", 
    payload="sub", 
    provider_token=YOOTOKEN, 
    currency="RUB", 
    start_parameter="Qblsupportbot", 
    prices=[{"label": "Руб", "amount": 30000}])

# test

Step = step()


@dp.message_handler(CommandStart())
async def bot_start(message: types.Message):
    await message.answer(f"""Привет, {message.from_user.full_name}, я бот куратор🤖
Я расскажу о преимуществах и правилах закрытой группы и канала.
А потом добавлю тебя  в туда ➕

Всего 3 шага и ты в чате!
Но сначала необходимо приобрести платную подписку:""", reply_markup=sub)



@dp.pre_checkout_query_handler()
async def process_pre_checkout_query(pre_checkout_query: types.PreCheckoutQuery):
    await bot.answer_pre_checkout_query(pre_checkout_query.id, ok=True)


@dp.message_handler(content_types=ContentType.SUCCESSFUL_PAYMENT)
async def process_pay(message: types.Message):
    if message.successful_payment.invoice_payload == "sub":
        await bot.send_message(message.from_user.id, "Если ты готов, то приступим:", reply_markup=step1)
